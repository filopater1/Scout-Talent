
  # Fix Recruitment Platform Issues

  This is a code bundle for Fix Recruitment Platform Issues. The original project is available at https://www.figma.com/design/fgEtnIGS0fKd0XLTZeakhS/Fix-Recruitment-Platform-Issues.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  